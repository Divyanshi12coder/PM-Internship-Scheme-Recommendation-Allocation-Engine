
  # SIH (final version)

  This is a code bundle for SIH (final version). The original project is available at https://www.figma.com/design/9c1iCqzyi7FvAWbPna0hFX/SIH--final-version-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  